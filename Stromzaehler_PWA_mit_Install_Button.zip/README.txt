STROMZÄHLER PWA

Enthalten:
- Marcel, Heizung, Elmar
- 12 Monate Zählerstände
- Monats- und Jahresverbrauch
- Kostenberechnung
- Strompreis und Grundgebühr
- lokale Speicherung
- Datensicherung/Wiederherstellung
- Offline-Cache
- App-Manifest und 192/512px App-Symbole

WICHTIG:
Für die echte PWA-Installation müssen diese Dateien über HTTPS bereitgestellt werden.
Lade den kompletten Inhalt dieses Ordners auf einen kostenlosen HTTPS-Webhost.
Danach die HTTPS-Adresse auf dem Samsung in Chrome öffnen und „App installieren“
bzw. „Zum Startbildschirm hinzufügen“ wählen.

Die Stromdaten werden lokal im Browser/auf dem Gerät gespeichert.
